# FlaskOAPro

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request

python main.py runserver

python main.py run

python main.py db migrate
python main.py db upgrade