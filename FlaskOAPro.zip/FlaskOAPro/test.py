import sqlite3

conn = sqlite3.connect('oa.sqlite')
cur = conn.cursor()

sql = """INSERT INTO person ( username, password, nick_name, gender, score, position_id)
VALUES ( 'zj', 'e10adc3949ba59abbe56e057f20f883e', '庄杰', '女', 1, 11);"""

# sql = """update attendance set start_time='2022-01-30 09:00:00.000000',
# end_time='2022-01-30 18:00:00.000000' where start_time like '2022-02-09 09:00:00%';"""

cur.execute(sql)
conn.commit()
print('Done.')
cur.close()
conn.close()